SELECT COUNT(DISTINCT UserID)
FROM Users U
WHERE U.Location == "New York";